import test, { test as base ,expect} from "@playwright/test";
import { SuppliersPage } from "../Pages/SuppliersPage";
import { CustomerPage } from "../Pages/CustomerPage";

test.describe('ERP Inventory Manage',()=>{

    test('suplier with single data',async({page})=>{
    const sup=new SuppliersPage(page)
    await sup.NavigateToSupliers()
    await sup.AddSupplierDetails(
    "Srini",
    "hyd1",
    "hyderabad",
    "india",
    "Qedgetech",
    "32525252",
    "Test@gmail.com",
    "2424234",
    "new suplier"
    )
    await sup.HandleAlerts()
    await sup.supplierTable()
    })
})